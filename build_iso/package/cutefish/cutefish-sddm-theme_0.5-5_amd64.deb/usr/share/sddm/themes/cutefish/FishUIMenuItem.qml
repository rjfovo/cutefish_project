/*
 * Copyright (C) 2021 CutefishOS.
 *
 * Author:     Reion Wong <reionwong@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import QtQuick 6.5
import QtQuick.Templates 6.5 as T
import FishUI 1.0 as FishUI

T.MenuItem {
    id: control

    property color hoveredColor: FishUI.Theme.darkMode ? Qt.rgba(255, 255, 255, 0.2)
                                                       : Qt.rgba(0, 0, 0, 0.1)
    property color pressedColor: FishUI.Theme.darkMode ? Qt.rgba(255, 255, 255, 0.1)
                                                       : Qt.rgba(0, 0, 0, 0.2)

    implicitWidth: Math.max(implicitBackgroundWidth + leftInset + rightInset,
                            implicitContentWidth + leftPadding + rightPadding)
    implicitHeight: Math.max(implicitBackgroundHeight + topInset + bottomInset,
                             implicitContentHeight + topPadding + bottomPadding)
    verticalPadding: FishUI.Units.smallSpacing
    horizontalPadding: FishUI.Units.smallSpacing * 2
    hoverEnabled: true
    topPadding: FishUI.Units.smallSpacing
    bottomPadding: FishUI.Units.smallSpacing

    contentItem: Text {
        leftPadding: control.mirrored ? control.rightPadding : control.leftPadding
        rightPadding: control.mirrored ? control.leftPadding : control.rightPadding
        text: control.text
        font: control.font
        color: control.enabled ? (control.pressed || control.hovered ? FishUI.Theme.highlightedTextColor
                                                                     : FishUI.Theme.textColor)
                               : FishUI.Theme.disabledTextColor
        elide: Text.ElideRight
        verticalAlignment: Text.AlignVCenter
        horizontalAlignment: Text.AlignLeft
    }

    background: Rectangle {
        implicitWidth: 200
        implicitHeight: control.visible ? FishUI.Units.rowHeightAlt : 0
        radius: FishUI.Theme.mediumRadius
        opacity: 1

        anchors {
            fill: parent
            leftMargin: FishUI.Units.smallSpacing
            rightMargin: FishUI.Units.smallSpacing
        }

        color: control.pressed || control.highlighted ? control.pressedColor
             : control.hovered ? control.hoveredColor
             : "transparent"
    }
}
