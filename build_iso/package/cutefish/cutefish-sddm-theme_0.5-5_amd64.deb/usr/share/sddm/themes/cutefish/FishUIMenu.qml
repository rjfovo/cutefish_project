/*
 * Copyright (C) 2021 CutefishOS.
 *
 * Author:     Reion Wong <reionwong@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import QtQuick 6.5
import QtQuick.Controls 6.5
import QtQuick.Templates 6.5 as T
import QtQuick.Layouts 6.5
import QtQuick.Window 6.5
import QtQuick.Effects
import FishUI 1.0 as FishUI

T.Menu {
    id: control

    implicitWidth: Math.max(200,
                            implicitBackgroundWidth + leftInset + rightInset,
                            contentWidth + leftPadding + rightPadding)
    implicitHeight: Math.max(implicitBackgroundHeight + topInset + bottomInset,
                             contentHeight + topPadding + bottomPadding)

    margins: 0
    verticalPadding: FishUI.Units.smallSpacing
    spacing: FishUI.Units.smallSpacing
    transformOrigin: !cascade ? Item.Top : (mirrored ? Item.TopRight : Item.TopLeft)

    delegate: FishUIMenuItem {}

    enter: Transition {
        NumberAnimation { property: "opacity"; from: 0; to: 1; duration: 100; easing.type: Easing.InOutCubic }
    }

    exit: Transition {
        NumberAnimation { property: "opacity"; from: 1; to: 0; duration: 200; easing.type: Easing.InOutCubic }
    }

    T.Overlay.modal: Rectangle {
        color: Qt.rgba(FishUI.Theme.backgroundColor.r,
                       FishUI.Theme.backgroundColor.g,
                       FishUI.Theme.backgroundColor.b, 0.4)
        Behavior on opacity { NumberAnimation { duration: 150; easing.type: Easing.InOutCubic } }
    }

    contentItem: ListView {
        id: listview
        anchors.fill: parent
        model: control.contentModel
        spacing: control.spacing
        clip: true
        keyNavigationEnabled: true
        keyNavigationWraps: true
        implicitWidth: contentWidth + leftPadding + rightPadding
        implicitHeight: contentHeight

        ScrollBar.vertical: ScrollBar {}
    }

    background: Rectangle {
        radius: FishUI.Theme.hugeRadius
        color: FishUI.Theme.backgroundColor
        opacity: 1

        layer.enabled: true
        layer.effect: MultiEffect {
            shadowEnabled: true
            shadowColor: Qt.rgba(0, 0, 0, 0.11)
            shadowBlur: 1.0
            shadowHorizontalOffset: 0
            shadowVerticalOffset: 0
        }
    }
}
