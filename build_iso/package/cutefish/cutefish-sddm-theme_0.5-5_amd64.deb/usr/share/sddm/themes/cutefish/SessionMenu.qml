/*
 * Copyright (C) 2021 CutefishOS.
 *
 * Author:     Reion Wong <reionwong@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Cutefish SDDM Theme - Qt6 Compatible Session Menu
 * Fixed for Qt6 + SDDM 0.21 (Debian 13)
 */

import QtQuick 6.5
import QtQuick.Controls 6.5
import QtQuick.Layouts 6.5
import FishUI 1.0 as FishUI

Item {
    id: root

    property int currentIndex: -1
    property int rootFontSize: 12

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight

    visible: sessionModel ? sessionModel.count > 0 : false

    // SDDM exposes sessionModel as a QAbstractItemModel (SessionModel), not
    // as a JavaScript ListModel.  Calling get() throws a TypeError in Qt6.
    function sessionName(index) {
        if (!sessionModel || index < 0 || index >= sessionModel.count)
            return ""

        // SessionModel roles: DirectoryRole = Qt.UserRole + 1,
        // FileRole = +2, TypeRole = +3, NameRole = +4.
        const modelIndex = sessionModel.index(index, 0)
        const name = sessionModel.data(modelIndex, 0x104)
        return name !== undefined ? name : ""
    }

    // ----------------
    // Displayed Label
    // ----------------
    Button {
        id: button
        anchors.fill: parent

        text: root.sessionName(root.currentIndex)
        font.pointSize: rootFontSize
        hoverEnabled: true

        contentItem: Text {
            text: button.text + "  ▾"
            color: "white"
            font: button.font
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }
        background: Rectangle {
            color: button.pressed ? Qt.rgba(255, 255, 255, 0.36)
                 : button.hovered ? Qt.rgba(255, 255, 255, 0.30)
                 : Qt.rgba(0, 0, 0, 0.28)
            radius: FishUI.Theme.mediumRadius
        }

        onClicked: popup.open()
    }

    // -----------
    // Popup Menu
    // -----------
    Popup {
        id: popup
        x: 0
        // The session button is anchored near the bottom of the greeter.
        // Open upward so the menu is actually visible.
        y: -popup.height - 4
        width: Math.max(160, button.implicitWidth)

        background: Rectangle {
            radius: 6
            color: FishUI.Theme.darkMode ? "#333" : "#fff"
            border.color: "#00000022"
        }

        contentItem: ListView {
            id: list
            implicitWidth: popup.availableWidth
            implicitHeight: contentHeight
            model: sessionModel
            spacing: 0
            clip: true
            boundsBehavior: Flickable.StopAtBounds

            delegate: Button {
                width: list.width
                height: 30
                text: model.name
                hoverEnabled: true

                contentItem: Text {
                    text: parent.text
                    color: parent.pressed ? FishUI.Theme.highlightedTextColor
                         : FishUI.Theme.darkMode ? "white" : "#323238"
                    font: parent.font
                    leftPadding: FishUI.Units.smallSpacing * 2
                    verticalAlignment: Text.AlignVCenter
                    horizontalAlignment: Text.AlignLeft
                }

                background: Rectangle {
                    radius: FishUI.Theme.smallRadius
                    color: parent.pressed || index === root.currentIndex ? FishUI.Theme.highlightColor
                         : parent.hovered ? Qt.rgba(0, 0, 0, 0.08)
                         : "transparent"
                }

                onClicked: {
                    root.currentIndex = index
                    popup.close()
                }
            }
        }
    }

    Component.onCompleted: {
        console.log("Cutefish SessionMenu: sessionModel=", sessionModel,
                    "count=", sessionModel ? sessionModel.count : -1,
                    "lastIndex=", sessionModel ? sessionModel.lastIndex : -1)
        if (sessionModel)
            currentIndex = sessionModel.lastIndex
    }
}
