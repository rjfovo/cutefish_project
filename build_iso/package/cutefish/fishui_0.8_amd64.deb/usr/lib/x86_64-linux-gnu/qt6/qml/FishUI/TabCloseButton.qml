/*
 * Copyright (C) 2021 CutefishOS Team.
 *
 * Author:     Reion Wong <reion@cutefishos.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import QtQuick 6.0
import QtQuick.Window 6.0
import QtQuick.Controls 6.0
import FishUI 1.0 as FishUI

Item {
    id: control

    property var size: 32
    property var iconMargins: 0
    height: size
    width: size

    property alias background: _background
    property color backgroundColor: "transparent"
    property color hoveredColor: "#FF273D"
    property color pressedColor: "#CF182B"
    property string source: ""
    // hover/按下时使用的图标（红色圆底上应使用白色图标）
    property string hoveredSource: ""
    property alias image: _image
    signal clicked()

    Rectangle {
        id: _background
        anchors.fill: parent
        anchors.margins: size * 0.1
        radius: control.height / 2
        opacity: 0.9
        color: mouseArea.pressed ? pressedColor : mouseArea.containsMouse ? control.hoveredColor : control.backgroundColor
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true

        onClicked: control.clicked()
    }

    Image {
        id: _image
        objectName: "image"
        anchors.fill: parent
        anchors.margins: control.iconMargins
        fillMode: Image.PreserveAspectFit
        sourceSize: Qt.size(width, height)
        cache: true
        asynchronous: false
        // hover/按下时优先使用 hoveredSource（红底上显示白色图标），否则用 source
        source: (mouseArea.containsMouse || mouseArea.pressed) && control.hoveredSource.length > 0
                ? control.hoveredSource : control.source
    }
}
