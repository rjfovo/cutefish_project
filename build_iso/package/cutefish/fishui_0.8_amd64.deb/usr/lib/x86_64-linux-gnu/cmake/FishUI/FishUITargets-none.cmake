#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "FishUI" for configuration "None"
set_property(TARGET FishUI APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(FishUI PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Qml;Qt6::Quick;Qt6::QuickControls2;KF6::WindowSystem"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libFishUI.so"
  IMPORTED_SONAME_NONE "libFishUI.so"
  )

list(APPEND _cmake_import_check_targets FishUI )
list(APPEND _cmake_import_check_files_for_FishUI "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libFishUI.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
