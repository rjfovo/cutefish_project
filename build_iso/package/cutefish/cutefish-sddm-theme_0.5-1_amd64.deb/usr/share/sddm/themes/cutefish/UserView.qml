/*
 * Copyright (C) 2021 CutefishOS.
 *
 * Author:     Reion Wong <reionwong@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import QtQuick 6.5
import QtQuick.Window 6.5
import QtQuick.Controls 6.5 as QQC2
import QtQuick.Layouts 6.5
import QtQuick.Effects     // Qt6 新增模块
import FishUI 1.0 as FishUI

ListView {
    id: control

    clip: true
    height: 80 + FishUI.Units.largeSpacing * 2
    orientation: ListView.Horizontal
    highlightRangeMode: ListView.StrictlyEnforceRange

    preferredHighlightBegin: width / 2 - userItemSize / 2
    preferredHighlightEnd: preferredHighlightBegin

    spacing: FishUI.Units.largeSpacing * 2
    property int userItemSize: 60

    delegate: Item {
        id: rootItem
        width: control.userItemSize
        height: ListView.view.height

        opacity: control.currentIndex === index ? 1.0 : 0.33
        scale: control.currentIndex === index ? 1.0 : 0.88

        property string displayName: model.realName || model.name
        property string userName: model.name

        MouseArea {
            id: clickArea
            anchors.fill: parent
            onClicked: control.currentIndex = index
        }

        ColumnLayout {
            anchors.fill: parent
            spacing: FishUI.Units.smallSpacing * 1.5

            // ----------------------
            // User Icon (Circular)
            // ----------------------
            Item {
                id: avatarWrapper
                Layout.alignment: Qt.AlignHCenter
                Layout.preferredWidth: control.userItemSize
                Layout.preferredHeight: control.userItemSize

                Image {
                    id: avatar
                    anchors.fill: parent
                    source: model.icon
                    fillMode: Image.PreserveAspectCrop
                    smooth: true

                    // small press animation
                    scale: clickArea.pressed ? 0.9 : 1.0
                    Behavior on scale {
                        NumberAnimation { duration: 100 }
                    }
                }

                // Qt6 Replacement for OpacityMask → MultiEffect
                MultiEffect {
                    anchors.fill: avatar
                    source: avatar

                    maskEnabled: true
                    maskSource: Rectangle {
                        width: avatar.width
                        height: avatar.height
                        radius: width / 2
                    }
                }
            }

            // ----------------------
            // User label
            // ----------------------
            QQC2.Label {
                Layout.alignment: Qt.AlignHCenter
                text: rootItem.displayName
                wrapMode: Text.NoWrap
                color: FishUI.Theme.textColor
            }
        }
    }
}
