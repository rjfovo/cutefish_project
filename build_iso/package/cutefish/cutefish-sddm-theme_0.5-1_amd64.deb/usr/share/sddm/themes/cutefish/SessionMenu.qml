/*
 * Copyright (C) 2021 CutefishOS.
 *
 * Author:     Reion Wong <reionwong@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Cutefish SDDM Theme - Qt6 Compatible Session Menu
 * Fixed for Qt6 + SDDM 0.20 (Debian 13)
 */

import QtQuick 6.5
import QtQuick.Controls 6.5
import QtQuick.Layouts 6.5
import QtQuick.Effects
import FishUI 1.0 as FishUI

Item {
    id: root

    property int currentIndex: -1
    property int rootFontSize: 12

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight

    visible: sessionModel ? sessionModel.count > 1 : false

    // ----------------
    // Displayed Label
    // ----------------
    Button {
        id: button
        anchors.fill: parent

        text: {
            if (currentIndex >= 0 && sessionModel) {
                // Qt6 compatible: use data() method
                var idx = sessionModel.index(currentIndex, 0)
                var name = sessionModel.data(idx, 0x100) // NameRole
                if (name !== undefined)
                    return name
                // fallback
                return ""
            }
            return ""
        }
        font.pointSize: rootFontSize
        background: Rectangle {
            color: "transparent"
        }

        onClicked: popup.open()
    }

    // -----------
    // Popup Menu
    // -----------
    Popup {
        id: popup
        x: button.left
        y: button.bottom + 4
        width: 160

        background: Rectangle {
            radius: 6
            color: FishUI.Theme.darkMode ? "#333" : "#fff"
            border.color: "#00000022"
        }

        Column {
            id: list
            width: parent.width

            Repeater {
                model: sessionModel

                delegate: Button {
                    width: popup.width
                    text: model.name

                    background: Rectangle {
                        color: hovered || pressed ? "#00000022" : "transparent"
                    }

                    onClicked: {
                        root.currentIndex = model.index
                        popup.close()
                    }
                }
            }
        }
    }

    Component.onCompleted: {
        if (sessionModel)
            currentIndex = sessionModel.lastIndex
    }
}
