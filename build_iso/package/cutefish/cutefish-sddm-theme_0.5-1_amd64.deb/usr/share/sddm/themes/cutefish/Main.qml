/*
 * Copyright (C) 2021 CutefishOS.
 *
 * Author:     Reion Wong <reionwong@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import QtQuick 6.5
import QtQuick.Window 6.5
import QtQuick.Controls 6.5 as QQC2
import QtQuick.Layouts 6.5
import QtQuick.Effects

import FishUI 1.0 as FishUI

import SddmComponents 2.0
import "./"

Item {
    id: root

    property string notificationMessage

    LayoutMirroring.enabled: Qt.locale().textDirection === Qt.RightToLeft
    LayoutMirroring.childrenInherit: true

    TextConstants { id: textConstants }

    // -----------------------------
    // Wallpaper
    // -----------------------------
    Image {
        id: wallpaperImage
        anchors.fill: parent
        source: "file:///usr/share/backgrounds/cutefishos/default.jpg"
        sourceSize: Qt.size(width * Screen.devicePixelRatio, height * Screen.devicePixelRatio)
        fillMode: Image.PreserveAspectCrop
        asynchronous: false
        clip: true
        smooth: true
    }

    MultiEffect {
        id: wallpaperBlur
        anchors.fill: parent
        source: wallpaperImage
        blurEnabled: true
        blurMax: 64
        blur: 1.0
        visible: true
    }

    // -----------------------------
    // Time + Date
    // -----------------------------
    Timer {
        repeat: true
        running: true
        interval: 1000

        onTriggered: {
            timeLabel.updateInfo()
            dateLabel.updateInfo()
        }
    }

    Component.onCompleted: {
        timeLabel.updateInfo()
        dateLabel.updateInfo()
    }

    // -----------------------------
    // Top Time Area
    // -----------------------------
    Item {
        id: _topItem
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: _mainItem.top
        anchors.bottomMargin: root.height * 0.1

        QQC2.Label {
            id: timeLabel
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.verticalCenter: parent.verticalCenter
            font.pointSize: 35
            color: "white"

            function updateInfo() {
                timeLabel.text = new Date().toLocaleString(Qt.locale(), "hh:mm")
            }
        }

        QQC2.Label {
            id: dateLabel
            anchors.top: timeLabel.bottom
            anchors.topMargin: FishUI.Units.largeSpacing
            anchors.horizontalCenter: parent.horizontalCenter
            font.pointSize: 19
            color: "white"

            function updateInfo() {
                dateLabel.text = new Date().toLocaleDateString(Qt.locale(), Locale.LongFormat)
            }
        }

        MultiEffect {
            anchors.fill: timeLabel
            source: timeLabel
            shadowEnabled: true
            shadowColor: Qt.rgba(0,0,0,0.8)
            shadowOpacity: 0.1
            shadowBlur: 0.5
            shadowHorizontalOffset: 0
            shadowVerticalOffset: 0
        }

        MultiEffect {
            anchors.fill: dateLabel
            source: dateLabel
            shadowEnabled: true
            shadowColor: Qt.rgba(0,0,0,0.8)
            shadowOpacity: 0.1
            shadowBlur: 0.5
            shadowHorizontalOffset: 0
            shadowVerticalOffset: 0
        }
    }

    // -----------------------------
    // Main Login Form
    // -----------------------------
    Item {
        id: _mainItem
        anchors.centerIn: parent
        width: 260 + FishUI.Units.largeSpacing * 3
        height: _mainLayout.implicitHeight + FishUI.Units.largeSpacing * 4

        Rectangle {
            anchors.fill: parent
            radius: FishUI.Theme.bigRadius + 2
            color: FishUI.Theme.darkMode ? "#424242" : "white"
            opacity: 0.5
        }

        ColumnLayout {
            id: _mainLayout
            anchors.fill: parent
            anchors.margins: FishUI.Units.largeSpacing * 1.5
            spacing: FishUI.Units.smallSpacing * 1.5

            // -------------- User List --------------
            UserView {
                id: _userView
                model: userModel
                Layout.fillWidth: true
            }

            // -------------- Password --------------
            QQC2.TextField {
                id: passwordField
                Layout.preferredHeight: 40
                Layout.preferredWidth: 260
                placeholderText: textConstants.password
                focus: true
                selectByMouse: true
                echoMode: TextInput.Password

                background: Rectangle {
                    color: FishUI.Theme.darkMode ? "#B6B6B6" : "white"
                    radius: FishUI.Theme.bigRadius
                    opacity: 0.5
                }

                Keys.onEnterPressed: root.startLogin()
                Keys.onReturnPressed: root.startLogin()
                Keys.onEscapePressed: passwordField.text = ""
            }

            // -------------- Login Button --------------
            QQC2.Button {
                id: unlockBtn
                Layout.preferredHeight: 40
                Layout.preferredWidth: 260
                text: textConstants.login
                onClicked: root.startLogin()

                scale: unlockBtn.pressed ? 0.95 : 1.0
                Behavior on scale { NumberAnimation { duration: 100 } }

                background: Rectangle {
                    color: FishUI.Theme.darkMode ? "#B6B6B6" : "white"
                    opacity: unlockBtn.pressed ? 0.3 : unlockBtn.hovered ? 0.4 : 0.5
                    radius: FishUI.Theme.bigRadius
                }
            }
        }
    }

    // -----------------------------
    // Session Menu (Qt6-fixed)
    // -----------------------------
    Item {
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.leftMargin: FishUI.Units.largeSpacing
        anchors.bottomMargin: FishUI.Units.largeSpacing

        width: sessionMenu.implicitWidth + FishUI.Units.largeSpacing
        height: sessionMenu.implicitHeight

        SessionMenu {
            id: sessionMenu
            anchors.fill: parent
            rootFontSize: 10
            height: 30
        }
    }

    // -----------------------------
    // Power Button
    // -----------------------------
    Item {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.rightMargin: FishUI.Units.largeSpacing
        anchors.bottomMargin: FishUI.Units.smallSpacing * 1.5
        width: 50
        height: 50 + FishUI.Units.largeSpacing

        FishUI.RoundImageButton {
            anchors.fill: parent
            size: 50
            source: "system-shutdown-symbolic.svg"
            iconMargins: FishUI.Units.largeSpacing
            onClicked: actionMenu.open()
        }
    }

    // -----------------------------
    // Power Menu
    // -----------------------------
    FishUIMenu {
        id: actionMenu

        QQC2.MenuItem {
            text: textConstants.suspend
            visible: sddm.canSuspend
            onClicked: sddm.suspend()
        }

        QQC2.MenuItem {
            text: textConstants.reboot
            visible: sddm.canReboot
            onClicked: sddm.reboot()
        }

        QQC2.MenuItem {
            text: textConstants.shutdown
            visible: sddm.canPowerOff
            onClicked: sddm.powerOff()
        }
    }

    // -----------------------------
    // Login Message / Notifications
    // -----------------------------
    QQC2.Label {
        id: message
        anchors.top: _mainItem.bottom
        anchors.topMargin: FishUI.Units.largeSpacing
        anchors.horizontalCenter: parent.horizontalCenter
        font.bold: true
        text: root.notificationMessage
        color: "white"

        opacity: text === "" ? 0 : 1

        Behavior on opacity { NumberAnimation { duration: 250 } }
    }

    MultiEffect {
        anchors.fill: message
        source: message
        shadowEnabled: true
        shadowColor: Qt.rgba(0,0,0,0.8)
        shadowOpacity: 0.1
        shadowBlur: 0.5
        shadowHorizontalOffset: 0
        shadowVerticalOffset: 0
    }

    // -----------------------------
    // Login Logic
    // -----------------------------
    function startLogin() {
        var username = _userView.currentItem.userName
        var password = passwordField.text
        root.notificationMessage = ""

        // Use session index (Qt6 standard)
        const sessionIndex = sessionMenu.currentIndex
        // Check if sessionModel exists and has count property
        if (sessionModel && sessionIndex >= 0 && sessionIndex < sessionModel.count) {
            sddm.login(username, password, sessionIndex)
        } else {
            // Fallback to default session
            sddm.login(username, password, 0)
        }
    }

    Timer {
        id: notificationResetTimer
        interval: 3000
        onTriggered: root.notificationMessage = ""
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            notificationMessage = textConstants.loginFailed
            notificationResetTimer.start()
        }
    }
}
