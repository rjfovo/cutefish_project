import QtQuick 6.5

Rectangle {
    id: root

    color: "#0A0F14"
    opacity: 1.0

    Behavior on opacity {
        NumberAnimation {
            duration: 360
            easing.type: Easing.OutCubic
        }
    }

    Image {
        id: background
        anchors.fill: parent
        source: "file:///usr/share/backgrounds/cutefishos/boot-background.png"
        fillMode: Image.PreserveAspectCrop
        asynchronous: false
        clip: true
        smooth: true
    }

    Image {
        id: wordmark
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        width: Math.min(parent.width * 0.24, 430)
        height: width * 0.5
        source: "file:///usr/share/plymouth/themes/cutefish-logo/logo.png"
        fillMode: Image.PreserveAspectFit
        smooth: true
        opacity: 0.92
    }
}
